﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            TcpListener server = null;
            NetworkStream stream = null;
            try
            {
                server = new TcpListener(IPAddress.Parse("192.168.1.235"), 160);
                server.Start();

                while (true)
                {
                    Console.WriteLine("\tОжидание подключения");

                    TcpClient client = server.AcceptTcpClient();
                    Console.WriteLine($"\tПодключён клиент - {client.Client.RemoteEndPoint}");
                    stream = client.GetStream();

                    byte[] data = new byte[10];
                    StringBuilder builder = new StringBuilder();
                    do
                    {
                        int bytes = stream.Read(data, 0, data.Length);
                        //builder.Append(Encoding.UTF8.GetString(data, 0, bytes));
                        builder.Append("grehgurhge\n\riurhgiug");
                    } while (stream.DataAvailable);

                    Console.WriteLine(builder.ToString());

                    stream.Close();
                    client.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
