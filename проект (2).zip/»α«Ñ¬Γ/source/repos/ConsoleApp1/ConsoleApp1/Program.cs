﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net.NetworkInformation;

namespace ConsoleApp1
{
    class Program
    {
        private const int port = 80;
        private const string server = "192.168.1.32";
        static void Main(string[] args)
        {
            TcpClient client = new TcpClient();
            client.Connect(server, port);
            NetworkStream netStream = client.GetStream();

            do
            {
                string response = Console.ReadLine();
                byte[] data = System.Text.Encoding.UTF8.GetBytes(response);
                netStream.Write(data, 0, data.Length);
            } while (true);
        }
    }
}
